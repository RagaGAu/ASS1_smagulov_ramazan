package Shopping;

public class PaymentProcessor {
    public void processPayment(PaymentStrategy paymentStrategy, double amount) {

        System.out.println("Verifying customer information...");

        System.out.println("\nPayment with Credit Card:");

        paymentStrategy.processPayment(amount);


        updateOrderStatus();
        sendPaymentConfirmation();
    }

    private void updateOrderStatus() {
        System.out.println("Updating order status to 'Paid'...");
    }

    private void sendPaymentConfirmation() {
        System.out.println("Sending payment confirmation email to the customer...");

    }
}
