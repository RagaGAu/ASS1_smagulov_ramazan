package Shopping;

public class CreditCardPayment implements PaymentStrategy {
    private String cardHolderName;
    private String cardNumber;
    private String cvv;

    public CreditCardPayment(String cardHolderName, String cardNumber, String cvv) {
        this.cardHolderName = cardHolderName;
        this.cardNumber = cardNumber;
        this.cvv = cvv;
    }

    @Override
    public void processPayment(double amount) {
        System.out.println("Processing credit card payment of $" + amount +
                " for card ending in " + getLastFourDigits(cardNumber));
    }

    private String getLastFourDigits(String cardNumber) {
        return cardNumber.substring(cardNumber.length() - 4);
    }
}
