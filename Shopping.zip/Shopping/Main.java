package Shopping;

public class Main {
    public static void main(String[] args) {
        // Demonstrate Singleton pattern
        System.out.println("Singleton demonstration:");
        ThreadSafetyTest.main(args);

        // Run the shopping scenario
        System.out.println("\nShopping scenario demonstration:");
        Demo shoppingDemo = new Demo();
        shoppingDemo.runDemo();
    }
}
