package Shopping;

public class Client {
    public static void main(String[] args) {

        Singleton singleton = Singleton.getInstance();


        singleton.demonstrateFunctionality();
    }
}