package Shopping;

public class CheckoutProcess {
    private PaymentStrategy paymentStrategy;

    public CheckoutProcess(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void checkout(ShoppingCart cart) {
        double totalAmount = cart.calculateTotalPrice();

        System.out.println("Cart content:");
        cart.displayCart();

        System.out.println("\nProcessing payment using the selected strategy:");
        paymentStrategy.processPayment(totalAmount);

        System.out.println("Checkout completed successfully.");
    }
}
