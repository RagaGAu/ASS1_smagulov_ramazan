package Shopping;

public class ThreadSafetyTest {
    public static void main(String[] args) {

        Thread thread1 = new Thread(() -> {
            Singleton singleton = Singleton.getInstance();
            System.out.println("Thread 1: Singleton instance hash code - " + singleton.hashCode());
        });

        Thread thread2 = new Thread(() -> {
            Singleton singleton = Singleton.getInstance();
            System.out.println("Thread 2: Singleton instance hash code - " + singleton.hashCode());
        });

        // Start the threads
        thread1.start();
        thread2.start();

        // Wait for threads to finish
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
