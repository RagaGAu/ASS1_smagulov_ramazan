

package Shopping;
import Shopping.PaymentStrategy;
import Shopping.Product;

import java.util.ArrayList;
        import java.util.List;
        import java.util.Objects;

public class ShoppingCart {
    private List<Product> products;

    public ShoppingCart() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double calculateTotalPrice() {
        double totalPrice = 0;
        for (Product product : products) {
            totalPrice += product.getPrice() * product.getQuantity();
        }
        return totalPrice;
    }

    public void displayCart() {
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public void checkout(PaymentStrategy creditCardPayment) {
    }

    @Override
    public int hashCode() {
        return Objects.hash(products);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ShoppingCart otherCart = (ShoppingCart) obj;
        return Objects.equals(products, otherCart.products);
    }
}
