package Shopping;

public class Demo {
    private ShoppingCart cart;

    public void runDemo() {
        // Create products
        Product product1 = new Product("Jordans", 10.0, 2);
        Product product2 = new Product("Asics", 15.0, 1);

        // Initialize the shopping cart
        cart = new ShoppingCart();

        // Add products to the shopping cart
        cart.addProduct(product1);
        cart.addProduct(product2);

        // Display the cart content
        System.out.println("Cart content:");
        cart.displayCart();

        // Create a payment strategy (e.g., credit card)
        PaymentStrategy creditCardPayment = new CreditCardPayment("Ramazan", "87778386504", "123");

        // Use the existing PaymentProcessor instance
        PaymentProcessor paymentProcessor = new PaymentProcessor();

        // Process payment with credit card for the total amount in the cart
        System.out.println("\nPayment with Credit Card:");
        paymentProcessor.processPayment(creditCardPayment, cart.calculateTotalPrice());
    }

    public static void main(String[] args) {
        // Run the demo
        Demo shoppingDemo = new Demo();
        shoppingDemo.runDemo();
    }
}
